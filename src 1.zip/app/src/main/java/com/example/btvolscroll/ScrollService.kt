package com.example.btvolscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.media.AudioManager
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScrollService : AccessibilityService() {

    private lateinit var am: AudioManager
    private var lastVol = 0
    private var lastKeyTime = 0L
    private var ignoreUntil = 0L
    private var lastPkg: String? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                != AudioManager.STREAM_MUSIC) return
            val now = SystemClock.uptimeMillis()
            if (now < ignoreUntil) return
            val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", lastVol)
            if (v == lastVol) return

            if (now - lastKeyTime < 500 || !shouldHandle()) {
                lastVol = v
            } else {
                scroll(forward = v > lastVol)
                ignoreUntil = now + 300
                am.setStreamVolume(AudioManager.STREAM_MUSIC, lastVol, 0)
            }
        }
    }

    override fun onServiceConnected() {
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        lastVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        registerReceiver(receiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"))
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
            lastKeyTime = SystemClock.uptimeMillis()
        return false
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString() ?: return
            if (p != "com.android.systemui" && !p.contains("inputmethod")) lastPkg = p
        }
    }

    override fun onInterrupt() {}

    private fun shouldHandle(): Boolean {
        if (!Prefs.enabled(this)) return false
        // Nếu không đọc được cửa sổ hiện tại (trang chủ nặng) thì dùng app đã ghi nhận gần nhất
        val pkg = rootInActiveWindow?.packageName?.toString() ?: lastPkg ?: return false
        return pkg in Prefs.apps(this)
    }

    private fun scroll(forward: Boolean) {
        val m = resources.displayMetrics
        val d = m.heightPixels * Prefs.amount(this)
        val cy = m.heightPixels / 2f
        val x = m.widthPixels * 0.8f            // lệch phải để tránh chạm vào ảnh/video ở giữa
        val (y1, y2) = if (forward) (cy + d / 2) to (cy - d / 2) else (cy - d / 2) to (cy + d / 2)
        val p = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 180)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCancelled(gd: GestureDescription?) { nodeScroll(forward) }
        }, null)
        if (!ok) nodeScroll(forward)
    }

    // Dự phòng: yêu cầu thẳng danh sách cuộn của app cuộn
    private fun nodeScroll(forward: Boolean) {
        val root = rootInActiveWindow ?: return
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                     else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val queue = ArrayDeque<AccessibilityNodeInfo>().apply { add(root) }
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n.isScrollable && n.performAction(action)) return
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
    }
}
