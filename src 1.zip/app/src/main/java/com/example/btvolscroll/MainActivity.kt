package com.example.btvolscroll

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private class AppItem(val pkg: String, val label: String, val icon: android.graphics.drawable.Drawable)

    private var all = listOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private lateinit var adapter: BaseAdapter
    private lateinit var status: TextView
    private var query = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }

        // Hàng tiêu đề + nút bật/tắt
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "BT Volume Scroll"; textSize = 22f
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Switch(this).apply {
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setEnabled(this@MainActivity, on) }
        })
        root.addView(head)

        // Trạng thái dịch vụ Trợ năng
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(4)) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Mở cài đặt Trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        // Mức cuộn
        root.addView(TextView(this).apply {
            text = "Mức cuộn"; textSize = 16f; setPadding(0, dp(12), 0, 0)
        })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val opts = listOf("Ngắn" to 0.175f, "Vừa" to 0.3f, "Dài" to 0.4f)
        val cur = Prefs.amount(this)
        opts.forEachIndexed { i, (name, v) ->
            rg.addView(RadioButton(this).apply {
                id = 100 + i; text = name
                isChecked = Math.abs(cur - v) < 0.01f
                setOnClickListener { Prefs.setAmount(this@MainActivity, v) }
            })
        }
        root.addView(rg)

        // Chọn app
        root.addView(TextView(this).apply {
            text = "Bật cuộn bằng tai nghe trong các app:"; textSize = 16f
            setPadding(0, dp(12), 0, dp(4))
        })
        root.addView(EditText(this).apply {
            hint = "Tìm app..."; setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s.toString(); filter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        })

        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val item = shown[p]
                val row = LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                row.addView(ImageView(this@MainActivity).apply { setImageDrawable(item.icon) },
                    LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(TextView(this@MainActivity).apply {
                    text = item.label; textSize = 16f; setPadding(dp(12), 0, 0, 0)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(CheckBox(this@MainActivity).apply {
                    isChecked = item.pkg in Prefs.apps(this@MainActivity)
                    isClickable = false; isFocusable = false
                })
                return row
            }
        }
        val list = ListView(this).apply {
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, p, _ ->
                val it = shown[p]
                val on = it.pkg !in Prefs.apps(this@MainActivity)
                Prefs.setApp(this@MainActivity, it.pkg, on)
                adapter.let { a -> (a as BaseAdapter).notifyDataSetChanged() }
            }
        }
        root.addView(list, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        loadApps()
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(intent, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        filter()
    }

    private fun filter() {
        shown.clear()
        shown.addAll(all.filter { it.label.contains(query, ignoreCase = true) })
        adapter.notifyDataSetChanged()
    }

    override fun onResume() {
        super.onResume()
        val flat = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val on = flat.contains("$packageName/")
        status.text = if (on) "Dịch vụ Trợ năng: ĐANG BẬT ✓"
                      else "Dịch vụ Trợ năng: CHƯA BẬT. Bấm nút bên dưới, chọn BT Volume Scroll và bật lên."
        status.setTextColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
    }
}
