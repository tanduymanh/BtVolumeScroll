package com.example.btvolscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.media.AudioManager
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class ScrollService : AccessibilityService() {

    private lateinit var am: AudioManager
    private var lastVol = 0
    private var lastKeyTime = 0L
    private var ignoreUntil = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                != AudioManager.STREAM_MUSIC) return
            val now = SystemClock.uptimeMillis()
            if (now < ignoreUntil) return                    // do chính app đặt lại
            val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", lastVol)
            if (v == lastVol) return

            if (now - lastKeyTime < 500 || !shouldHandle()) {
                lastVol = v                                  // nút cứng trên máy: để chỉnh âm bình thường
            } else {                                         // nút tai nghe: cuộn, giữ nguyên âm
                swipe(up = v > lastVol)
                ignoreUntil = now + 300
                am.setStreamVolume(AudioManager.STREAM_MUSIC, lastVol, 0)
            }
        }
    }

    override fun onServiceConnected() {
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        lastVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        registerReceiver(receiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"))
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
            lastKeyTime = SystemClock.uptimeMillis()
        return false   // luôn để hệ thống chỉnh âm cho nút cứng
    }

    private fun shouldHandle(): Boolean {
        if (!Prefs.enabled(this)) return false
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return false
        return pkg in Prefs.apps(this)
    }

    private fun swipe(up: Boolean) {
        val m = resources.displayMetrics
        val d = m.heightPixels * Prefs.amount(this)
        val cy = m.heightPixels / 2f
        val x = m.widthPixels / 2f
        val (y1, y2) = if (up) (cy + d / 2) to (cy - d / 2) else (cy - d / 2) to (cy + d / 2)
        val p = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 250)).build(),
            null, null
        )
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
