package com.example.btvolscroll

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun apps(c: Context): Set<String> = sp(c).getStringSet("apps", emptySet()) ?: emptySet()
    fun setApp(c: Context, pkg: String, on: Boolean) {
        val s = apps(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("apps", s).apply()
    }

    // Tỉ lệ quãng vuốt so với chiều cao màn hình
    fun amount(c: Context) = sp(c).getFloat("amount", 0.6f)
    fun setAmount(c: Context, v: Float) = sp(c).edit().putFloat("amount", v).apply()
}
